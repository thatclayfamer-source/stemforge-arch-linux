
"""
STEAMFORGE MK-V - DESKTOP APP (NOT A WEBAPP)
Native Tkinter + CustomTkinter. No browser needed except embedded HtmlFrame for HTML games.
Scans local folders only. Server is OPTIONAL.
"""
import os, sys, pathlib, json, subprocess, time
from datetime import datetime
ROOT = pathlib.Path(__file__).parent
MEDIA_ROOT = ROOT / "media"
GAMES_HTML_ROOT = ROOT / "games" / "html"
GAMES_SH_ROOT = ROOT / "games" / "shgames"
DATA_ROOT = ROOT / "data"
FAV_FILE = DATA_ROOT / "favorites.json"
SAVE_FILE = DATA_ROOT / "saves.json"

import customtkinter as ctk
from tkinterweb import HtmlFrame

COLORS = {"bg":"#0e0d0b","bg_panel":"#1a1816","bg_card":"#221f1b","border":"#3d3429","brass":"#c9a86a","copper":"#b87333","text":"#e8dcc8","text_dim":"#8a7d6b"}
ctk.set_appearance_mode("dark")

def scan_movies():
    movies=[]
    p=MEDIA_ROOT/"movies"
    if p.exists():
        for f in p.iterdir():
            if f.is_file() and f.suffix.lower() in {".mp4",".mkv",".avi",".mov",".webm"} and not f.name.startswith("."):
                movies.append({"name":f.stem,"path":str(f)})
    return sorted(movies, key=lambda x: x["name"].lower())

def scan_shows():
    shows={}
    s_root=MEDIA_ROOT/"shows"
    if not s_root.exists(): return {}
    for show_dir in s_root.iterdir():
        if not show_dir.is_dir() or show_dir.name.startswith("."): continue
        seasons={}
        for season_dir in show_dir.iterdir():
            if not season_dir.is_dir() or season_dir.name.startswith("."): continue
            eps=[{"name":ep.stem,"path":str(ep)} for ep in season_dir.iterdir() if ep.is_file() and ep.suffix.lower() in {".mp4",".mkv",".avi",".mov"} and not ep.name.startswith(".")]
            if eps: seasons[season_dir.name]=sorted(eps, key=lambda x: x["name"].lower())
        if seasons: shows[show_dir.name]=seasons
    return shows

def scan_html_games():
    games=[]
    if not GAMES_HTML_ROOT.exists(): return games
    for folder in GAMES_HTML_ROOT.iterdir():
        if not folder.is_dir() or folder.name.startswith("."): continue
        for name in ["game.html","game.htm","index.html","index.htm"]:
            p=folder/name
            if p.exists():
                games.append({"name":folder.name,"path":str(p)}); break
    return sorted(games, key=lambda x: x["name"].lower())

def scan_sh_games():
    games=[]
    if not GAMES_SH_ROOT.exists(): return games
    for folder in GAMES_SH_ROOT.iterdir():
        if not folder.is_dir() or folder.name.startswith("."): continue
        for f in folder.iterdir():
            if f.suffix==".sh" and not f.name.startswith("."):
                games.append({"name":folder.name,"path":str(f)}); break
    return sorted(games, key=lambda x: x["name"].lower())

def load_favs():
    if FAV_FILE.exists():
        try: return json.loads(FAV_FILE.read_text())
        except: pass
    return {"games":[],"media":[]}
def save_favs(d): FAV_FILE.write_text(json.dumps(d, indent=2))
def load_saves():
    if SAVE_FILE.exists():
        try: return json.loads(SAVE_FILE.read_text())
        except: pass
    return {"locked_by":None,"lock_time":None,"saves":{},"current_user":None}
def save_saves(d): SAVE_FILE.write_text(json.dumps(d, indent=2))

class FullscreenPlayer(ctk.CTkToplevel):
    def __init__(self, master, media_path, media_type="video"):
        super().__init__(master)
        self.attributes("-fullscreen", True); self.configure(fg_color="black")
        self.media_path=media_path
        self.lock_save()
        self.hint=ctk.CTkLabel(self, text="ALT + ESC to close  |  Move mouse to show", font=("Consolas",11), text_color="#fff", fg_color="#000")
        self.hint.place(relx=1.0, rely=1.0, anchor="se", x=-20, y=-20)
        self.last_move=time.time()
        self.bind("<Motion>", lambda e: (setattr(self,'last_move',time.time()), self.hint.place(relx=1.0, rely=1.0, anchor="se", x=-20, y=-20)))
        self.bind("<Alt-Escape>", lambda e: self.close_player())
        self.bind("<Escape>", lambda e: self.close_player())
        self.after(100, self.check_idle)
        self.html=HtmlFrame(self); self.html.pack(fill="both", expand=True)
        if media_type=="html":
            self.html.load_website(pathlib.Path(media_path).as_uri())
        else:
            uri=pathlib.Path(media_path).as_uri()
            html=f'<html><body style="margin:0;background:black;display:flex;justify-content:center;align-items:center;height:100vh"><video controls autoplay style="width:100%;height:100%;background:black" src="{uri}"></video></body></html>'
            tmp=DATA_ROOT/"_tmp_player.html"; tmp.write_text(html)
            self.html.load_website(tmp.as_uri())
        self.focus_set(); self.grab_set()
    def check_idle(self):
        if time.time()-self.last_move>5: self.hint.place_forget()
        self.after(500, self.check_idle)
    def lock_save(self):
        d=load_saves(); d["locked_by"]="player1"; d["lock_time"]=datetime.now().isoformat(); d["current_user"]="player1"
        d["saves"][pathlib.Path(self.media_path).name]={"last_played":datetime.now().isoformat(),"path":self.media_path}
        save_saves(d)
    def close_player(self): self.grab_release(); self.destroy()

class ShowBrowser(ctk.CTkToplevel):
    def __init__(self, master, show_name, seasons_dict, on_play):
        super().__init__(master); self.geometry("900x600"); self.configure(fg_color=COLORS["bg_panel"]); self.on_play=on_play
        ctk.CTkLabel(self, text=show_name.upper(), font=("Consolas",18,"bold"), text_color=COLORS["brass"]).pack(pady=12)
        self.tab=ctk.CTkTabview(self, fg_color=COLORS["bg_card"], segmented_button_fg_color=COLORS["bg_panel"], segmented_button_selected_color=COLORS["copper"], text_color=COLORS["text"])
        self.tab.pack(fill="both", expand=True, padx=12, pady=12)
        for season_name, episodes in seasons_dict.items():
            self.tab.add(season_name); frame=self.tab.tab(season_name)
            scroll=ctk.CTkScrollableFrame(frame, fg_color=COLORS["bg"]); scroll.pack(fill="both", expand=True)
            for ep in episodes:
                row=ctk.CTkFrame(scroll, fg_color=COLORS["bg_panel"], border_width=1, border_color=COLORS["border"], corner_radius=8); row.pack(fill="x", pady=4)
                ctk.CTkLabel(row, text=ep["name"], font=("Consolas",11), text_color=COLORS["text"]).pack(side="left", padx=12, pady=8)
                ctk.CTkButton(row, text="PLAY ▶", width=80, fg_color=COLORS["copper"], text_color="black", command=lambda p=ep["path"]: self.play(p)).pack(side="right", padx=8, pady=6)
    def play(self, path): self.destroy(); self.on_play(path)

class App(ctk.CTk):
    def __init__(self):
        super().__init__(); self.title("STEAMFORGE - DESKTOP (NOT WEBAPP)"); self.geometry("1350x850"); self.configure(fg_color=COLORS["bg"]); self.favs=load_favs(); self._build_ui(); self.refresh_all()
    def _build_ui(self):
        top=ctk.CTkFrame(self, height=60, fg_color=COLORS["bg_panel"], border_width=1, border_color=COLORS["border"], corner_radius=0); top.pack(fill="x", side="top"); top.pack_propagate(False)
        ctk.CTkLabel(top, text="⚙ STEAMFORGE  [DESKTOP APP]", font=("Consolas",18,"bold"), text_color=COLORS["brass"]).pack(side="left", padx=20)
        ctk.CTkButton(top, text="↻ RESCAN", width=80, fg_color=COLORS["bg"], border_width=1, border_color=COLORS["copper"], text_color=COLORS["copper"], command=self.refresh_all).pack(side="right", padx=20)
        self.main_tabs=ctk.CTkTabview(self, fg_color=COLORS["bg"], segmented_button_fg_color=COLORS["bg_panel"], segmented_button_selected_color=COLORS["copper"], text_color=COLORS["text"])
        self.main_tabs.pack(fill="both", expand=True, padx=10, pady=10)
        for t in ["GAMES","MEDIA","BROWSER","FAVORITES"]: self.main_tabs.add(t)
        games_frame=self.main_tabs.tab("GAMES"); self.games_sub=ctk.CTkTabview(games_frame, fg_color=COLORS["bg_panel"]); self.games_sub.pack(fill="both", expand=True)
        self.games_sub.add("HTML"); self.games_sub.add("SH GAMES")
        self.html_list=ctk.CTkScrollableFrame(self.games_sub.tab("HTML"), fg_color=COLORS["bg"]); self.html_list.pack(fill="both", expand=True, padx=6, pady=6)
        self.sh_list=ctk.CTkScrollableFrame(self.games_sub.tab("SH GAMES"), fg_color=COLORS["bg"]); self.sh_list.pack(fill="both", expand=True, padx=6, pady=6)
        media_frame=self.main_tabs.tab("MEDIA"); self.media_sub=ctk.CTkTabview(media_frame, fg_color=COLORS["bg_panel"]); self.media_sub.pack(fill="both", expand=True)
        self.media_sub.add("MOVIES"); self.media_sub.add("SHOWS")
        self.movie_list=ctk.CTkScrollableFrame(self.media_sub.tab("MOVIES"), fg_color=COLORS["bg"]); self.movie_list.pack(fill="both", expand=True, padx=6, pady=6)
        self.show_list=ctk.CTkScrollableFrame(self.media_sub.tab("SHOWS"), fg_color=COLORS["bg"]); self.show_list.pack(fill="both", expand=True, padx=6, pady=6)
        browser_frame=self.main_tabs.tab("BROWSER")
        nav=ctk.CTkFrame(browser_frame, fg_color=COLORS["bg_card"], height=40); nav.pack(fill="x", side="top"); nav.pack_propagate(False)
        self.url_entry=ctk.CTkEntry(nav, placeholder_text="Search DuckDuckGo or URL...", width=500, fg_color=COLORS["bg_panel"], border_color=COLORS["border"])
        self.url_entry.pack(side="left", padx=10, pady=6, fill="x", expand=True); self.url_entry.bind("<Return>", lambda e: self.navigate())
        ctk.CTkButton(nav, text="GO", width=60, fg_color=COLORS["copper"], text_color="black", command=self.navigate).pack(side="left", padx=5)
        ctk.CTkButton(nav, text="DuckDuckGo", width=110, fg_color=COLORS["bg_panel"], border_width=1, border_color=COLORS["border"], command=lambda: self.load_url("https://lite.duckduckgo.com")).pack(side="left", padx=5)
        self.browser=HtmlFrame(browser_frame); self.browser.pack(fill="both", expand=True); self.browser.load_website("https://lite.duckduckgo.com")
        fav_frame=self.main_tabs.tab("FAVORITES"); self.fav_list=ctk.CTkScrollableFrame(fav_frame, fg_color=COLORS["bg"]); self.fav_list.pack(fill="both", expand=True, padx=6, pady=6)
    def navigate(self):
        q=self.url_entry.get().strip()
        if not q: return
        url=q if q.startswith("http") else ("https://"+q if "." in q and " " not in q else f"https://lite.duckduckgo.com/lite/?q={q.replace(' ','+')}")
        self.load_url(url)
    def load_url(self, url):
        try: self.browser.load_website(url); self.url_entry.delete(0,"end"); self.url_entry.insert(0,url)
        except: pass
    def refresh_all(self):
        for f in [self.html_list, self.sh_list, self.movie_list, self.show_list, self.fav_list]:
            for w in f.winfo_children(): w.destroy()
        for g in scan_html_games(): self._add_game_card(self.html_list, g)
        for g in scan_sh_games(): self._add_game_card(self.sh_list, g, True)
        for m in scan_movies(): self._add_media_card(self.movie_list, m)
        shows=scan_shows()
        for show_name, seasons in shows.items():
            card=ctk.CTkFrame(self.show_list, fg_color=COLORS["bg_card"], border_width=1, border_color=COLORS["border"], corner_radius=10); card.pack(fill="x", pady=6)
            ctk.CTkLabel(card, text=show_name.upper(), font=("Consolas",13,"bold"), text_color=COLORS["brass"]).pack(side="left", padx=12, pady=12)
            ctk.CTkButton(card, text="BROWSE SEASONS", fg_color=COLORS["bg_panel"], border_width=1, border_color=COLORS["copper"], text_color=COLORS["copper"], command=lambda n=show_name, s=seasons: ShowBrowser(self,n,s,self.play_video)).pack(side="right", padx=10)
        self.favs=load_favs()
        for item in self.favs.get("games",[])+self.favs.get("media",[]):
            card=ctk.CTkFrame(self.fav_list, fg_color=COLORS["bg_card"], border_width=1, border_color=COLORS["border"], corner_radius=8); card.pack(fill="x", pady=4)
            ctk.CTkLabel(card, text=f"★ {item}", text_color=COLORS["brass"]).pack(side="left", padx=12, pady=8)
    def _add_game_card(self, parent, g, is_sh=False):
        card=ctk.CTkFrame(parent, fg_color=COLORS["bg_card"], border_width=1, border_color=COLORS["border"], corner_radius=10); card.pack(fill="x", pady=5)
        ctk.CTkLabel(card, text=g["name"].upper(), font=("Consolas",12,"bold"), text_color=COLORS["text"]).pack(side="left", padx=12, pady=10)
        ctk.CTkButton(card, text="PLAY ▶", width=80, fg_color=COLORS["copper"], text_color="black", command=lambda p=g["path"], t=is_sh: self.play_game(p,t)).pack(side="right", padx=10)
    def _add_media_card(self, parent, m):
        card=ctk.CTkFrame(parent, fg_color=COLORS["bg_card"], border_width=1, border_color=COLORS["border"], corner_radius=10); card.pack(fill="x", pady=5)
        ctk.CTkLabel(card, text=m["name"], font=("Consolas",11,"bold"), text_color=COLORS["text"]).pack(side="left", padx=12, pady=10)
        ctk.CTkButton(card, text="PLAY ▶", width=80, fg_color=COLORS["copper"], text_color="black", command=lambda p=m["path"]: self.play_video(p)).pack(side="right", padx=10)
    def play_video(self, path): FullscreenPlayer(self, path, "video")
    def play_game(self, path, is_sh):
        if is_sh:
            try: os.chmod(path, 0o755); subprocess.Popen(["bash", path])
            except: pass
        FullscreenPlayer(self, path, "html")
if __name__=="__main__": App().mainloop()
