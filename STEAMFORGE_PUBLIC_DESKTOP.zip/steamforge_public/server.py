
# OPTIONAL SERVER - only if you want to host your library for others
# Client works 100% without this. This is NOT required for Windows/Linux users.
from flask import Flask, jsonify, send_from_directory
import pathlib, json
ROOT = pathlib.Path(__file__).parent
app = Flask(__name__)
@app.route("/api/scan")
def scan():
    return jsonify({"note":"client is desktop app, server optional"})
if __name__=="__main__":
    app.run(host="0.0.0.0", port=8080)
