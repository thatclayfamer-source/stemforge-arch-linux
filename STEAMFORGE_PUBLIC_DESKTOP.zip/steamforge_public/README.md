
# ⚙ STEAMFORGE - DESKTOP APP (NOT A WEBAPP)

**This is a native desktop app, NOT a browser webapp.** Built with Python + CustomTkinter + TkinterWeb. Runs offline.

### What it does
- Scans local folders:
  - `media/movies/*.mp4 *.mkv`
  - `media/shows/ShowName/Season 1/Episode.mp4`
  - `games/html/GameName/game.html`
  - `games/shgames/GameName/run.sh`
- Fullscreen player: auto-hides UI after 5 sec, ALT+ESC to close
- Shows -> click to open seasons pseudo-window
- Browser tab = DuckDuckGo Lite (embedded, with URL bar)
- Favorites + single-user save lock (server-wide if using server.py)

### Does NOT require server
- `client.py` works 100% offline, standalone. No internet, no hosting.
- `server.py` is OPTIONAL only if you want to share your library over LAN/internet.

### Install

**Windows (no server needed):**
```bat
git clone https://github.com/YOURUSERNAME/steamforge.git
cd steamforge
pip install -r requirements.txt
python client.py
```
Or download `STEAMFORGE.exe` from Releases.

**Linux / Arch (no server needed):**
```bash
git clone https://github.com/YOURUSERNAME/steamforge.git
cd steamforge
sudo pacman -S python tk mpv vlc
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python client.py
```

**Arch Server (OPTIONAL - only to share):**
```bash
python server.py
# -> http://0.0.0.0:8080
```

### Build exe for Windows users
```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name STEAMFORGE client.py
```

### Structure
```
media/movies/
media/shows/
games/html/
games/shgames/
data/favorites.json
data/saves.json (single-user lock)
```
